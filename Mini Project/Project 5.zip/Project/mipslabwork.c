/* mipslabwork.c

   This file written 2015 by F Lundevall
   Updated 2017-04-21 by F Lundevall

   This file should be changed by YOU! So you must
   add comment(s) here with your name(s) and date(s):

   This file modified 2017-04-31 by Ture Teknolog 

   For copyright and licensing, see file COPYING */

#include <stdio.h>
#include <stdlib.h>   /* For NULL */
#include <stdint.h>   /* Declarations of uint_32 and the like */
#include <pic32mx.h>  /* Declarations of system-specific addresses etc */
#include "mipslab.h"  /* Declatations for these labs */

#define SNAKE_X_START 64
#define SNAKE_Y_START 16
#define SIZE_OF_BODY 4

#define LEFT 4
#define RIGHT 3
#define UP 2
#define DOWN 1

#define colMax 125 //number of display columns (3 less to compensate for the snake being 4 pixels large)
#define rowMax 29 //number of display rows
#define pagedMax 4 //number of display memory pages

int mytime = 0x5957;
int timeoutcount;

/* Default varibles to get the game going, we need to initilize the game*/
int foodX;
int foodY;
int score;
int foodAlive;
int direction;
int startupDelay;

struct snake_body* snake_head;

// Defines type snake_body
typedef struct snake_body{
  int x;
  int y;
  struct snake_body* next;
}snake_body;

/* Interrupt Service Routine */
// This function is called when an interrupt is found
void user_isr( void )
{
  /* Use the Timer to move the snake */
  if(IFS(0) & 0x100){
    timeoutcount++;
    if(timeoutcount == 4){
      switch(direction){
        case LEFT:
          update_snake(0, -SIZE_OF_BODY);
          break;
        case RIGHT:
          update_snake(0, SIZE_OF_BODY);
          break;
        case UP:
          update_snake(-SIZE_OF_BODY, 0);
          break;
        case DOWN:
          update_snake(SIZE_OF_BODY, 0);
          break;
      }
      timeoutcount = 0;
    }

    // bit 8 (Flag) (Acknowledges the interrupt)
    // Therefor we clear the flag
    IFSCLR(0) = 0x100;
  }
}

/* Lab-specific initialization goes here */
void labinit( void )
{
  volatile int* E = (volatile int*) 0xbf886100;
  *E = *E & 0xffffff00;
  //Clock
  // and btn 2-4 (D 0xe0)
  TRISDSET = 0b111111100000;
  TMR2 = 0;
  PR2 = 31250;
  T2CON = 0x8070; 

  //btn 1
  TRISFSET = 0b10;
  
  // Initialization of interrupts
  // bit 8 (Enable)
  IEC(0) = 0x100;
  // bit 4:2 (Priority) och 1:0 (Subpriority)
  IPC(2) = 0x10;    

  // Call function in labwork.S to enable interrupts globally
  enable_interrupt();

  // Makes room in the heap for a "snake_body"
  snake_head->next = NULL;
  snake_head->x = SNAKE_X_START;
  snake_head->y = SNAKE_Y_START; // Creates snake_head, pointing att an empty body


  foodX = 88;
  foodY = 24;
  score = 0;
  foodAlive = 0;
  direction = 0;
  startupDelay = 0;
  

  return;
}


//Controlls the movement of the snake, moving in four directions
void movement(void){
  int button =  getbtns();
  startupDelay++;
  //Delay timer to not start the game instantly
  if(startupDelay > 50)
  {
    //Scenarios depending on which button was pressed
    switch(button)
    {
      case 8: //Button 4 (Left)
        if(direction != 3)
          direction = 4;
        break;
      case 4: //Button 3 (Right)
        if(direction != 4)
          direction = 3;
        break;
      case 2: //Button 2 (Up)
        if(direction != 1)
          direction = 2;
        break;
      case 1: //Button 1 (Down)
        if(direction != 2)
          direction = 1;
        break;

      default:
        break;
    } 
  }
}

/* Looks if the snake has collided with the wall, and if so it jumps 
*  out of the main loop and sends us to the "game over" screen. */
void end_screen(){
  //Check if snake is outside of the screen
  if(snake_head->x > colMax || snake_head->y > rowMax || snake_head->x < 4|| snake_head->y < 4)
  {
    inGame = 0;
  }
}

/* Collects the apple and removes it from the playing field spawning a new one */
void appleCollision(){
  //Check if snake is on food
  if(snake_head->y == foodY && snake_head->x == foodX)
  {
    //Grow snake by one length
    foodX = randomNumber(121) + 4;
    foodY = randomNumber(25) + 4;
    score++;
  }
}

/* Generats a sudo-randum number withing the interval 0-28 for Y and 0-124 for X. 
*  They shall also be divisible by four */
int randomNumber(int interval)
{
  int flag = 1;
  int rand;
  while(flag)
  {
    rand = TMR2%interval;
    if(rand%4 == 0)
    {
      flag = 0;
    }
  }
  return rand; 
}

void update_snake(int increment_y, int increment_x){
  snake_body *current = snake_head;

  while(current->next != NULL){
    int prevX = current->x;
    int prevY = current->y;
    snake_body *next = current->next;

    next->x = prevX;
    next->y = prevY;
    current = next;
  }

  snake_head->x = snake_head->x + increment_x;
  snake_head->y = snake_head->y + increment_y;
}

void add_body(void){
    snake_body *current = snake_head;

  while(current->next != NULL){
    snake_body *next = current->next;

    current = next;
  }

  snake_body *new;
  new->next = NULL;
  new->x = current->x;
  new->y = current->y;
  current->next = new;  
}

void spawn_body(void){
  snake_body *current = snake_head;
  while(current->next != NULL){

    snake_body *next = current->next;
    current = next;
    head(current->y,current->x);
  }
}

//Spawns in the key essentials of the game, such as the map, the snake and the apples
void spawn(void){
  head(snake_head->y,snake_head->x);
  //spawn_body();
  apple(foodY,foodX);
  map();
}

/* This function is called repetitively from the main program */
void labwork( void )
{    
  //clear screen
  int i,j;
	for(i = 0; i < 32; i++){
    for(j = 0; j < 128; j++){
      pixel[i][j] = 0;
    }
  }

  spawn();
  //movement();
  end_screen();
  //appleCollision();

  fullscreen_display_update();
}
